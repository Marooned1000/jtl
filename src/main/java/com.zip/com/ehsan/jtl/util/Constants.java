package com.ehsan.jtl.util;

public class Constants {
	public static final String DEFAULT_AGENT_NAME = "agent";
}
